# Reproducibility and validation

The 1.0.3 maintenance candidate starts from the CRAN 1.0.2 source archive,
published on 2020-02-29. It repairs compatibility and interface errors while
retaining the historical local quadratic approximation solver, initialization,
lambda grid, contiguous CV folds, elimination threshold and iteration cap.

The article is [Yuzbasi, Arashi and Akdeniz (2021)](https://doi.org/10.1007/s00500-021-05763-9).
The published algorithm is described in Section 3.1. Package examples demonstrate
the interfaces; they do not claim to reproduce the article's tables or figures.

## Input dictionary

| Input | Meaning |
| --- | --- |
| `X` | Numeric design matrix: rows are observations, columns are predictors |
| `y` | Numeric response vector with one entry per observation |
| `q` | Positive bridge-penalty exponent, at most two |
| `lambda` | Nonnegative fitted penalty grid |
| `R` | Restriction matrix with one column per standardized predictor |
| `r` | Target vector or one-column matrix with one entry per restriction |
| `eta` | Historical elimination and squared coefficient-change threshold |
| `converge` | Initial convergence-distance value |
| `nfolds` | Number of contiguous validation folds |
| `num_threads` | Requested fold-level thread count when supported by the build |

Missing or nonfinite data, constant predictors and incompatible dimensions are
rejected. The package does not impute missing values or silently remove constant
predictors. Supply linearly independent restriction rows. The historical solver
does not return iteration counts or a convergence certificate; validate a fitted
path before substantive interpretation.

## Checking restriction scales

The restriction defines linear combinations of standardized predictor slopes.
The fitted intercept is excluded. To inspect the restriction residual, use the
same column deviations as the solver. In this example `path` is a fitted
restricted model; `X`, `R` and `r` are its supplied inputs.

```r
center <- colMeans(X)
scale <- sqrt(colMeans(sweep(X, 2, center, "-")^2))
standardized_slopes <- path$betas[-1, , drop = FALSE] * scale
restriction_residual <- sweep(R %*% standardized_slopes, 1, as.numeric(r), "-")
max(abs(restriction_residual))
```

The calculated residual measures departure from each supplied standardized-scale
restriction over the fitted path. Thresholding can affect residuals. This check
does not certify convergence or global optimality.

## Local validation

The maintenance tests exercise an independent ridge reference for `q = 2`,
coefficient and prediction methods, restriction scales, small CV fits and invalid
inputs. Use a single BLAS/OpenMP thread for reproducible small checks.

From the directory containing a built source archive:

```sh
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
  R CMD check --as-cran rbridge_1.0.3.tar.gz
```

Record `sessionInfo()` and package versions with any study outputs. Examples use
seed 2019. The repository's published version and software environment should be
recorded separately from any data-analysis configuration.

## Reproducing the published study

The package source provides estimators and demonstrations. The original complete
simulation and empirical reproduction drivers are not included in this source
archive. A full reproduction requires the original datasets, configuration,
seeds and scripts; neither the README demonstration nor a successful package
check establishes agreement with the published results.
