scalar_predict <- function(object, newx, s, type) {
  if (type == "nonzero") {
    return(nonzeroCoef(object$betas[-1L, , drop = FALSE], bystep = TRUE))
  }
  if (is.numeric(s)) {
    index <- match(s, object$lambda)
    if (!length(index) || anyNA(index))
      stop("Numeric s must match values in object$lambda")
  } else {
    if (length(s) != 1L) stop("s must specify one named selector")
    selected <- object[[s]]
    if (is.null(selected)) {
      if (s == "lambda.min") selected <- min(object$lambda)
      else stop("lambda.1se requires a cross-validated model; use numeric s for a path model")
    }
    index <- match(selected, object$lambda)
    if (anyNA(index)) stop("Selected lambda is absent from the fitted path")
  }
  coefficients <- object$betas[, index, drop = FALSE]
  if (type == "coefficients") return(coefficients)
  if (missing(newx)) stop("newx must be supplied for response predictions")
  if (is.numeric(newx) && is.null(dim(newx))) newx <- matrix(newx, nrow = 1L)
  if (!is.matrix(newx) || !is.numeric(newx))
    stop("newx must be a numeric vector or matrix")
  if (ncol(newx) + 1L != nrow(object$betas))
    stop("newx does not have the right number of columns")
  output <- cbind(1, newx) %*% coefficients
  if (ncol(output) == 1L) as.numeric(output) else output
}
#' @title Make predictions from a 'cv.rbridge' object
#' @param object A 'cv.rbridge' object.
#' @param newx Matrix of new values for x at which predictions are to be made.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param type One of "response", "nonzero" or "coefficients". The "response" is for predicted values, the "nonzero" is for exacting non-zero coefficients and the "coefficients" is for the estimated coefficients. 
#' @param ... Additional arguments for compatibility.
#' @return Response predictions (a vector for one lambda, a matrix for several), a coefficient matrix, or nonzero indices over the entire path when \code{type = "nonzero"}.
#' @description
#' Makes predictions from a cross-validated 'cv.rbridge' model
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{coef.cv.rbridge}}
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' ### Restricted Matrix and vector
#' c1 <- c(1,1,0,0,1,0,0,0)
#' R1.mat <- matrix(c1,nrow = 1, ncol = p)
#' r1.vec <- as.matrix(c(6.5),1,1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' ######## Model 1 based on first restrictions
#' model1 <- cv.rbridge(X, y, q = 1, R1.mat, r1.vec, nlambda = 5, nfolds = 3, num_threads = 1)
#' coef(model1,s='lambda.min')
#' predict(model1,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model1, s="lambda.min",type="coefficient")
#' @export
predict.cv.rbridge = function(object, newx, s=c("lambda.min","lambda.1se"),
                              type = c("response", "nonzero","coefficients"), ...) {
  type <- match.arg(type)
  if (!is.numeric(s)) s <- match.arg(s)
  scalar_predict(object, newx, s, type)
}




#' @title Extract coefficients from a 'cv.rbridge' object
#' @param object A 'cv.rbridge' object.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param ... Additional arguments for compatibility.
#' @return A matrix of coefficients including the intercept.
#' @description
#' Extract coefficients from a 'cv.rbridge' object.
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{predict.cv.rbridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' ### Restricted Matrix and vector
#' c1 <- c(1,1,0,0,1,0,0,0)
#' R1.mat <- matrix(c1,nrow = 1, ncol = p)
#' r1.vec <- as.matrix(c(6.5),1,1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' ######## Model 1 based on first restrictions
#' model1 <- cv.rbridge(X, y, q = 1, R1.mat, r1.vec, nlambda = 5, nfolds = 3, num_threads = 1)
#' coef(model1,s='lambda.min')
#' @export
coef.cv.rbridge=function(object, s=c("lambda.1se","lambda.min"),...) {
  if (!is.numeric(s)) s <- match.arg(s)
  predict(object, s=s, type="coefficients")
}



#' @title Make predictions from a 'rbridge' object
#' @param object A 'rbridge' object.
#' @param newx Matrix of new values for x at which predictions are to be made.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param type One of "response", "nonzero" or "coefficients". The "response" is for predicted values, the "nonzero" is for exacting non-zero coefficients and the "coefficients" is for the estimated coefficients. 
#' @param ... Additional arguments for compatibility.
#' @return Response predictions (a vector for one lambda, a matrix for several), a coefficient matrix, or nonzero indices over the entire path when \code{type = "nonzero"}.
#' @description
#' Makes predictions from a cross-validated 'rbridge' model
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{coef.cv.bridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' ### Restricted Matrix and vector
#' c1 <- c(1,1,0,0,1,0,0,0)
#' R1.mat <- matrix(c1,nrow = 1, ncol = p)
#' r1.vec <- as.matrix(c(6.5),1,1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' ######## Model 1 based on first restrictions
#' model1 <- rbridge(X, y, q = 1, R1.mat, r1.vec, nlambda = 5)
#' predict(model1,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model1, s="lambda.min",type="coefficient")
#' @export
predict.rbridge = function(object, newx, s=c("lambda.min","lambda.1se"),
                              type = c("response", "nonzero","coefficients"), ...) {
  type <- match.arg(type)
  if (missing(s)) s <- object$lambda
  else if (!is.numeric(s)) s <- match.arg(s)
  scalar_predict(object, newx, s, type)
}

#' @title Extract coefficients from a 'rbridge' object
#' @param object A 'rbridge' object.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param ... Additional arguments for compatibility.
#' @return Response predictions (a vector for one lambda, a matrix for several), a coefficient matrix, or nonzero indices over the entire path when \code{type = "nonzero"}.
#' @description
#' Makes predictions from a cross-validated 'rbridge' model
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{predict.rbridge}}
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' ### Restricted Matrix and vector
#' c1 <- c(1,1,0,0,1,0,0,0)
#' R1.mat <- matrix(c1,nrow = 1, ncol = p)
#' r1.vec <- as.matrix(c(6.5),1,1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' ######## Model 1 based on first restrictions
#' model1 <- rbridge(X, y, q = 1, R1.mat, r1.vec, nlambda = 5)
#' coef(model1,s='lambda.min')
#' 
#' @export
coef.rbridge=function(object, s=c("lambda.1se","lambda.min"),...) {
  if (missing(s)) s <- object$lambda
  else if (!is.numeric(s)) s <- match.arg(s)
  predict(object, s=s, type="coefficients")
}



#### Bridge
#' @title Make predictions from a 'cv.bridge' object
#' @param object A 'cv.bridge' object.
#' @param newx Matrix of new values for x at which predictions are to be made.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param type One of "response", "nonzero" or "coefficients". The "response" is for predicted values, the "nonzero" is for exacting non-zero coefficients and the "coefficients" is for the estimated coefficients. 
#' @param ... Additional arguments for compatibility.
#' @return Response predictions (a vector for one lambda, a matrix for several), a coefficient matrix, or nonzero indices over the entire path when \code{type = "nonzero"}.
#' @description
#' Makes predictions from a cross-validated 'cv.bridge' model
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{coef.cv.bridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' model1 <- cv.bridge(X, y, q = 1, nlambda = 5, nfolds = 3, num_threads = 1)
#' coef(model1,s='lambda.min')
#' predict(model1,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model1, s="lambda.min",type="coefficient")
#' @export
predict.cv.bridge = function(object, newx, s=c("lambda.min","lambda.1se"),
                              type = c("response", "nonzero","coefficients"), ...) {
  type <- match.arg(type)
  if (!is.numeric(s)) s <- match.arg(s)
  scalar_predict(object, newx, s, type)
}




#' @title Extract coefficients from a 'cv.bridge' object
#' @param object A 'cv.bridge' object.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param ... Additional arguments for compatibility.
#' @return  A vector of coefficients
#' @description
#' Extract coefficients from a 'cv.bridge' object.
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{predict.cv.rbridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' model1 <- cv.bridge(X, y, q = 1, nlambda = 5, nfolds = 3, num_threads = 1)
#' coef(model1,s='lambda.min')
#' @export
coef.cv.bridge=function(object, s=c("lambda.1se","lambda.min"),...) {
  if (!is.numeric(s)) s <- match.arg(s)
  predict(object, s=s, type="coefficients")
}



#' @title Make predictions from a 'bridge' object
#' @param object A 'bridge' object.
#' @param newx Matrix of new values for x at which predictions are to be made.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param type One of "response", "nonzero" or "coefficients". The "response" is for predicted values, the "nonzero" is for exacting non-zero coefficients and the "coefficients" is for the estimated coefficients. 
#' @param ... Additional arguments for compatibility.
#' @return Response predictions (a vector for one lambda, a matrix for several), a coefficient matrix, or nonzero indices over the entire path when \code{type = "nonzero"}.
#' @description
#' Makes predictions from a cross-validated 'bridge' model
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{coef.bridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' model1 <- bridge(X, y, q = 1, nlambda = 5)
#' predict(model1,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model1, s="lambda.min",type="coefficient")
#' @export
predict.bridge = function(object, newx, s=c("lambda.min","lambda.1se"),
                              type = c("response", "nonzero","coefficients"), ...) {
  type <- match.arg(type)
  if (missing(s)) s <- object$lambda
  else if (!is.numeric(s)) s <- match.arg(s)
  scalar_predict(object, newx, s, type)
}

#' @title Extract coefficients from a 'bridge' object
#' @param object A 'bridge' object.
#' @param s Exact fitted lambda value(s), or a named selector. CV objects use \code{lambda.min} or \code{lambda.1se}; prediction defaults to the former and coefficient extraction to the latter. Path objects return all fitted columns when \code{s} is omitted. For a path, \code{lambda.min} means the smallest fitted lambda; \code{lambda.1se} requires CV.
#' @param ... Additional arguments for compatibility.
#' @return  A vector of coefficients
#' @description
#' Extract coefficients from a 'bridge' object.
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{predict.bridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' model1 <- bridge(X, y, q = 1, nlambda = 5)
#' coef(model1,s='lambda.min')
#' @export
coef.bridge=function(object, s=c("lambda.1se","lambda.min"),...) {
  if (missing(s)) s <- object$lambda
  else if (!is.numeric(s)) s <- match.arg(s)
  predict(object, s=s, type="coefficients")
}



#' @title Plot a 'cv.rbridge' object function
#' @param x Design matrix.
#' @param sign.lambda Either plot against \code{log(lambda)} (default) or its negative if sign.\code{lambda=-1}.
#' @param ... Other graphical parameters to plot
#' @description
#' Plots the cross-validation curve, and upper and lower standard deviation curves, as a function of the lambda values used.
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @rdname plot.cv.rbridge
#' @export
plot.cv.rbridge=function(x,sign.lambda=1,...){
  object = x
  xlab="log(Lambda)"
  if(sign.lambda<0)xlab=paste("-",xlab,sep="")
  plot.args=list(x=sign.lambda*log(object$lambda),
                 y=object$cve,ylim=range(object$cvup,object$cvlo),
                 xlab=xlab,ylab='Mean-Squared Error',type="n")
  new.args <- list(...)
  if (length(new.args)) 
    plot.args[names(new.args)] <- new.args
  do.call("plot", plot.args)
  er.bars(sign.lambda*log(object$lambda),object$cvup,object$cvlo,width=0.01,col="darkgrey")
  points(sign.lambda*log(object$lambda),object$cve,pch=20,col="red")
  axis(side=3,at=sign.lambda*log(object$lambda),labels=paste(object$nz),tick=FALSE,line=0)
  abline(v=sign.lambda*log(object$lambda.min),lty=3)
  abline(v=sign.lambda*log(object$lambda.1se),lty=3)
  invisible()
}



### Bridge
#' @title Plot a 'cv.bridge' object function
#' @param x Design matrix.
#' @param sign.lambda Either plot against \code{log(lambda)} (default) or its negative if sign.\code{lambda=-1}.
#' @param ... Other graphical parameters to plot
#' @description
#' Plots the cross-validation curve, and upper and lower standard deviation curves, as a function of the lambda values used.
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @rdname plot.cv.bridge
#' @export
plot.cv.bridge=function(x,sign.lambda=1,...){
  object = x
  xlab="log(Lambda)"
  if(sign.lambda<0)xlab=paste("-",xlab,sep="")
  plot.args=list(x=sign.lambda*log(object$lambda),
                 y=object$cve,ylim=range(object$cvup,object$cvlo),
                 xlab=xlab,ylab='Mean-Squared Error',type="n")
  new.args <- list(...)
  if (length(new.args)) 
    plot.args[names(new.args)] <- new.args
  do.call("plot", plot.args)
  er.bars(sign.lambda*log(object$lambda),object$cvup,object$cvlo,width=0.01,col="darkgrey")
  points(sign.lambda*log(object$lambda),object$cve,pch=20,col="red")
  axis(side=3,at=sign.lambda*log(object$lambda),labels=paste(object$nz),tick=FALSE,line=0)
  abline(v=sign.lambda*log(object$lambda.min),lty=3)
  abline(v=sign.lambda*log(object$lambda.1se),lty=3)
  invisible()
}
