# rbridge 1.0.3 (unreleased)

* Restore default prediction and coefficient extraction on current R versions.
* Path objects return the full coefficient or prediction path when `s` is
  omitted. Numeric `s` selects exact fitted lambda values. For path objects,
  `s = "lambda.min"` selects the smallest fitted lambda; `lambda.1se` requires CV.
* Forward `num_threads` and `converge` from cross-validation wrappers, and honor
  the supplied initial `converge` value in the solver. The default is unchanged.
* Reject nonfinite data, constant predictors, invalid penalty parameters,
  invalid fold counts and incompatible restriction dimensions before fitting.
* Replace deprecated Armadillo scalar conversion and remove obsolete C++11
  requests. Reuse the fixed design cross-product in the restricted solver.
* Update authorship, dependencies, published article citation and documentation.
* Preserve the historical solver, lambda grid, folds, thresholds and the
  standardized coefficient scale used for restrictions. Returned coefficients
  remain on the original predictor scale.

# rbridge 1.0.2

* Previous CRAN release, published on 2020-02-29.
