#' @export
#' @title Cross-validation for rbridge
#' @param X Design matrix with n observation rows and p predictor columns.
#' @param y Numeric response vector with one value per observation.
#' @param q is the degree of norm which includes ridge regression with \code{q=2} and lasso estimates with \code{q=1} as special cases
#' @param R Numeric matrix with m restriction rows and p predictor columns. Each row defines one linear combination of standardized slopes; use linearly independent rows.
#' @param r Target vector or one-column matrix with m values. Writing beta for
#' the p-dimensional standardized predictor-coefficient vector, the restriction
#' residual is zero when all supplied linear restrictions hold:
#' \deqn{r - R\beta = 0.}
#' This expression specifies the target coefficient subspace; the intercept
#' is excluded. Standardized predictor coefficients have response units.
#' @param lambda User-supplied penalty sequence; generated internally when omitted.
#' @param nfolds number of folds - default is 10.
#' @param lambda.min The smallest value for lambda if \code{n>p} is \code{0.001} and \code{0.05} otherwise.
#' @param nlambda The number of lambda values - default is \code{100}
#' @param eta Positive threshold used for coefficient elimination and the squared coefficient-change stopping rule. The default is \code{1e-7}; it is unchanged from the historical solver.
#' @param converge Initial convergence-distance value, retained for compatibility. The default is \code{10^10}. The solver updates the squared Euclidean coefficient change and stops when it is at most \code{eta}, or after the historical iteration cap.
#' @param num_threads Number of threads used for parallel computation over the folds,

#' @return An object of class cv.rbridge, a list with entries
#' \item{cve}{the prediction error aggregated over the validation folds.}
#' \item{cvse}{the historical CV error-bar calculation, retained for compatibility.}
#' \item{cvup}{upper curve = \code{cve+cvse}.}
#' \item{cvlo}{lower curve = \code{cve-cvse}.}
#' \item{lambda}{the values of \code{lambda} used in the fits}
#' \item{nz}{number of non-zero coefficients at each \code{lambda}.}
#' \item{betas}{estimated coefficient at each \code{lambda}.}
#' \item{lambda.min}{value of lambda that gives minimum \code{cve}}
#' \item{lambda.1se}{largest value of \code{lambda} such that error is within 1 standard error of the minimum}



#' @description
#' Performs cross-validation for restricted bridge models and returns the fitted path and selected lambda values. Use plot() to display the result.
#' 
#' @details
#' Predictors are centered and divided by their root-mean-square centered
#' deviations. The restriction is imposed on the coefficients of these
#' standardized predictors, not on the original-scale coefficients returned
#' in \code{betas}. Here \code{R} has one column per predictor and one row
#' per restriction; \code{r} contains the corresponding target values.
#' The restriction rows must be linearly independent. The reconstructed
#' intercept is not included in the restrictions. Check restriction residuals
#' after accounting for predictor scales, especially when thresholding occurs.
#'
#' Computes cv.rbridge
#' 
#' 
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{rbridge}}
#' 
#' 
#' @examples
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' p.active <- which(beta != 0)
#' 
#' ### Restricted Matrix and vector
#' ### Res 1
#' c1 <- c(1,1,0,0,1,0,0,0)
#' R1.mat <- matrix(c1,nrow = 1, ncol = p)
#' r1.vec <- as.matrix(c(6.5),1,1)
#' ### Res 2
#' c2 <- c(-1,1,0,0,1,0,0,0)
#' R2.mat <- matrix(c2,nrow = 1, ncol = p)
#' r2.vec <- matrix(c(0.5),nrow = 1, ncol = 1)
#' ### Res 3
#' R3.mat <- t(matrix(c(c1,c2),nrow = p, ncol = 2))
#' r3.vec <- matrix(c(6.5,0.5),nrow = 2, ncol = 1)
#' ### Res 4
#' R4.mat = diag(1,p,p)[-p.active,]
#' r4.vec <- matrix(rep(0,p-length(p.active)),nrow = p-length(p.active), ncol = 1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' ######## Model 1 based on first restrictions
#' model1 <- cv.rbridge(X, y, q = 1, R1.mat, r1.vec, nlambda = 5, nfolds = 3, num_threads = 1)
#' print(model1)
#' coef(model1,s='lambda.min')
#' coef(model1,s='lambda.1se')
#' predict(model1,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model1, s="lambda.min",type="coefficient")
#' predict(model1, s="lambda.1se",type="coefficient")
#' 
#' ######## Model 2 based on second restrictions
#' model2 <- cv.rbridge(X, y, q = 1, R2.mat, r2.vec, nlambda = 5, nfolds = 3, num_threads = 1)
#' print(model2)
#' coef(model2,s='lambda.min')
#' coef(model2,s='lambda.1se')
#' predict(model2,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model2, s="lambda.min",type="coefficient")
#' predict(model2, s="lambda.1se",type="coefficient")
#' 
#' ######## Model 3 based on third restrictions
#' model3 <- cv.rbridge(X, y, q = 1, R3.mat, r3.vec, nlambda = 5, nfolds = 3, num_threads = 1)
#' print(model3)
#' coef(model3,s='lambda.min')
#' coef(model3,s='lambda.1se')
#' predict(model3,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model3, s="lambda.min",type="coefficient")
#' predict(model3, s="lambda.1se",type="coefficient")
#' 
#' ######## Model 4 based on fourth restrictions
#' model4 <- cv.rbridge(X, y, q = 1, R4.mat, r4.vec, nlambda = 5, nfolds = 3, num_threads = 1)
#' print(model4)
#' coef(model4,s='lambda.min')
#' coef(model4,s='lambda.1se')
#' predict(model4,newx=X[1:5,], s="lambda.min", type="response")
#' predict(model4, s="lambda.min",type="coefficient")
#' predict(model4, s="lambda.1se",type="coefficient")
#' 
#' 
cv.rbridge = function (X, y, q, R,r, lambda,nfolds=10,
                       lambda.min=ifelse(n>p,.001,.05), nlambda=100,
                       eta=1e-7, converge=10^10,num_threads = 10) {
  if (!is(X, "matrix")) {
    tmp <- try(X <- model.matrix(~0+., data=X), silent=TRUE)
    if (class(tmp)[1] == "try-error") 
      stop("X must be a matrix or able to be coerced to a matrix")
  }
  if (storage.mode(X)=="integer") 
    storage.mode(X) <- "double"
  
  if (!is(y, "numeric")) {
    tmp <- try(y <- as.numeric(y), silent=TRUE)
    if (class(tmp)[1] == "try-error") 
      stop("y must numeric or able to be coerced to numeric")
  }
  if (length(nfolds) != 1L || !is.finite(nfolds) ||
      nfolds != as.integer(nfolds) || nfolds < 2L || nfolds > nrow(X))
    stop("nfolds must be an integer between 2 and nrow(X)")
  if (length(num_threads) != 1L || !is.finite(num_threads) ||
      num_threads != as.integer(num_threads) || num_threads < 1L)
    stop("num_threads must be a positive integer")
  if (length(y) != nrow(X) || anyNA(X) || anyNA(y) ||
      any(!is.finite(X)) || any(!is.finite(y)))
    stop("X and y must be finite and have matching observation counts")

  .validate_bridge_data(X, y, q, eta, converge)
  .validate_bridge_restriction(R, r, ncol(X))
  r <- matrix(r, ncol = 1L)

  ## Set up XX, yy, lambda
  stdX <- standard(X)
  XX <- stdX$xx
  p <- ncol(XX)
  ns <- c(1:p)
  yy <- y - mean(y)
  n <- length(yy)
  if (missing(lambda)) {
    if (length(nlambda) != 1L || !is.finite(nlambda) ||
        nlambda != as.integer(nlambda) || nlambda < 2L)
      stop("nlambda must be an integer of at least 2")
    if (length(lambda.min) != 1L || !is.finite(lambda.min) || lambda.min <= 0)
      stop("lambda.min must be a finite positive number")
    lambda <- Lambdas_Grid(XX, yy,q,lambda.min, nlambda)
    user.lambda <- FALSE
  } else {
    nlambda <- length(lambda)
    user.lambda <- TRUE
  }
  .validate_bridge_lambda(lambda)
  fit <- CV_RBridge(XX,yy,q, lambda, R,r, eta=eta, converge=converge, num_folds=nfolds ,num_threads=num_threads)
  cve <- apply(fit, 1, sum)
  cvse <- sqrt(apply(scale(t(fit), cve, FALSE)^2, 2, mean,na.rm = TRUE)/(n - 1))
  rbridge.fit = rbridge(X, y, q, R,r,lambda=lambda,eta=eta, converge=converge)
  nz = sapply(predict(rbridge.fit, type = "nonzero"),
              length)
  val <- list(cve = cve, cvse = cvse, cvup = cve + cvse, 
              cvlo = cve - cvse, lambda = lambda, nz=nz, 
              betas = rbridge.fit$betas )
  lamin <- getmin(lambda, cve, cvse) 
  obj = c(val, as.list(lamin))
  class(obj) = "cv.rbridge"
  obj
}




