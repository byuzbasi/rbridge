#' @useDynLib rbridge, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom methods is
NULL
#' @importFrom stats model.matrix predict
#' @importFrom graphics abline axis points segments
#' @importClassesFrom Matrix dgCMatrix
#' 
#' @title Fit a Restricted Bridge Estimation
#' @param X Design matrix with n observation rows and p predictor columns.
#' @param y Numeric response vector with one value per observation.
#' @param q is the degree of norm which includes ridge regression with \code{q=2} and lasso estimates with \code{q=1} as special cases
#' @param R Numeric matrix with m restriction rows and p predictor columns. Each row defines one linear combination of standardized slopes; use linearly independent rows.
#' @param r Target vector or one-column matrix with m values. Writing beta for
#' the p-dimensional standardized predictor-coefficient vector, the restriction
#' residual is zero when all supplied linear restrictions hold:
#' \deqn{r - R\beta = 0.}
#' This expression specifies the target coefficient subspace; the intercept
#' is excluded. Standardized predictor coefficients have response units.
#' @param lambda.min The smallest value for lambda if \code{n>p} is \code{0.001} and \code{0.05} otherwise.
#' @param nlambda The number of lambda values - default is \code{100}
#' @param lambda A user supplied lambda sequence. By default, the program compute a squence of values the length of nlambda.
#' @param eta Positive threshold used for coefficient elimination and the squared coefficient-change stopping rule. The default is \code{1e-7}; it is unchanged from the historical solver.
#' @param converge Initial convergence-distance value, retained for compatibility. The default is \code{10^10}. The solver updates the squared Euclidean coefficient change and stops when it is at most \code{eta}, or after the historical iteration cap.

#' @return An object of class rbridge, a list with entries
#' \item{betas}{Coefficients computed over the path of lambda}
#' \item{lambda}{The lambda values which is given at the function}

#' @description
#' Fit a restricted bridge-penalized least-squares path using local quadratic approximation.
#' It is computed the regularization path which is consisted of \code{lasso} or \code{ridge} penalty 
#' at the a grid values for \code{lambda}
#' 
#' 
#' @details
#' Predictors are centered and divided by their root-mean-square centered
#' deviations. The restriction is imposed on the coefficients of these
#' standardized predictors, not on the original-scale coefficients returned
#' in \code{betas}. Here \code{R} has one column per predictor and one row
#' per restriction; \code{r} contains the corresponding target values.
#' The restriction rows must be linearly independent. The reconstructed
#' intercept is not included in the restrictions. Check restriction residuals
#' after accounting for predictor scales, especially when thresholding occurs.
#'
#' In order to couple the bridge estimator with the restriction \code{R beta = r}, 
#' we solve the following optimization problem
#' Here RSS denotes the residual sum of squares for the centered response and
#' standardized design. The operator min denotes minimization over the slope
#' vector beta; the q-indexed expression denotes the bridge penalty constraint.
#' The following compact statement combines that penalty with the supplied
#' linear restrictions, and is implemented through local quadratic approximation:
#'\deqn{\min RSS w.r.t ||\beta||_q and R\beta = r. }
#' The exponent q controls the penalty shape; n is the observation count and
#' p is the predictor count. See Section 3.1 of the cited article for the
#' computation. The expression describes the estimator, not a guarantee of
#' global convergence for every supplied dataset.
#'
#' 
#' 
#' @references Yuzbasi, B., Arashi, M. and Akdeniz, F. (2021). Penalized regression via the restricted bridge estimator. Soft Computing, 25, 8401--8416. \doi{10.1007/s00500-021-05763-9}.
#'
#' @author Bahadir Yuzbasi, Mohammad Arashi and Fikri Akdeniz \cr Maintainer: Bahadir Yuzbasi \email{b.yzb@hotmail.com}
#' 
#' @seealso \code{\link{cv.rbridge}}
#' 
#' @export
#' 
#' @examples 
#' set.seed(2019) 
#' beta <- c(3, 1.5, 0, 0, 2, 0, 0, 0)
#' p <- length(beta)
#' beta <- matrix(beta, nrow = p, ncol = 1)
#' p.active <- which(beta != 0)
#' 
#' ### Restricted Matrix and vector
#' ### Res 1
#' c1 <- c(1,1,0,0,1,0,0,0)
#' R1.mat <- matrix(c1,nrow = 1, ncol = p)
#' r1.vec <- as.matrix(c(6.5),1,1)
#' ### Res 2
#' c2 <- c(-1,1,0,0,1,0,0,0)
#' R2.mat <- matrix(c2,nrow = 1, ncol = p)
#' r2.vec <- matrix(c(0.5),nrow = 1, ncol = 1)
#' ### Res 3
#' R3.mat <- t(matrix(c(c1,c2),nrow = p, ncol = 2))
#' r3.vec <- matrix(c(6.5,0.5),nrow = 2, ncol = 1)
#' ### Res 4
#' R4.mat = diag(1,p,p)[-p.active,]
#' r4.vec <- matrix(rep(0,p-length(p.active)),nrow = p-length(p.active), ncol = 1)
#' 
#' n = 100
#' X = matrix(rnorm(n*p),n,p)
#' y = X%*%beta + rnorm(n) 
#' 
#' ######## Model 1 based on first restrictions
#' model1 <- rbridge(X, y, q = 1, R1.mat, r1.vec, nlambda = 5)
#' print(model1)
#' 
#' ######## Model 2 based on second restrictions
#' model2 <- rbridge(X, y, q = 1, R2.mat, r2.vec, nlambda = 5)
#' print(model2)
#' 
#' ######## Model 3 based on third restrictions
#' model3 <- rbridge(X, y, q = 1, R3.mat, r3.vec, nlambda = 5)
#' print(model3)
#' 
#' ######## Model 4 based on fourth restrictions
#' model4 <- rbridge(X, y, q = 1, R4.mat, r4.vec, nlambda = 5)
#' print(model4)
#' 
rbridge <- function(X, y, q=1, R,r,lambda.min=ifelse(n>p,.001,.05), nlambda=100,
                   lambda, eta=1e-7, converge=10^10) {
  
  # Coersion
  if (!is(X, "matrix")) {
    tmp <- try(X <- model.matrix(~0+., data=X), silent=TRUE)
    if (class(tmp)[1] == "try-error") 
      stop("X must be a matrix or able to be coerced to a matrix")
  }
  if (storage.mode(X)=="integer") 
    storage.mode(X) <- "double"
  
  if (!is(y, "numeric")) {
    tmp <- try(y <- as.numeric(y), silent=TRUE)
    if (class(tmp)[1] == "try-error") 
      stop("y must numeric or able to be coerced to numeric")
  }
  
  
  # Error checking
  if (any(is.na(y)) | any(is.na(X))) stop("Missing data (NA's) detected.  Take actions (e.g., removing cases, removing features, imputation) to eliminate missing data before passing X and y to ncvreg")
  if (length(y) != nrow(X)) stop("X and y do not have the same number of observations")
  
  .validate_bridge_data(X, y, q, eta, converge)
  .validate_bridge_restriction(R, r, ncol(X))
  r <- matrix(r, ncol = 1L)

  ## Set up XX, yy, lambda
  stdX <- standard(X)
  XX <- stdX$xx
  p <- ncol(XX)
  ns <- c(1:p)
  yy <- y - mean(y)
  n <- length(yy)
  
  if (missing(lambda)) {
    if (length(nlambda) != 1L || !is.finite(nlambda) ||
        nlambda != as.integer(nlambda) || nlambda < 2L)
      stop("nlambda must be an integer of at least 2")
    if (length(lambda.min) != 1L || !is.finite(lambda.min) || lambda.min <= 0)
      stop("lambda.min must be a finite positive number")
    #lambda <- as.double(rev(sort(Lambdas_Grid(XX, yy,q,lambda.min, nlambda))))
    lambda <- Lambdas_Grid(XX, yy,q,lambda.min, nlambda)
    user.lambda <- FALSE
  } else {
    nlambda <- length(lambda)
    user.lambda <- TRUE
  }
  .validate_bridge_lambda(lambda)
    
  ## Fit
    fit <- RBridge(XX, yy, q, lambda, R, r,converge, eta)
    constant <- rep(mean(y),nlambda)
    betas <- matrix(fit, p, nlambda)
    #loss <- res[[2]]
    #iter <- res[[3]]
    
    
  ## Unstandardize
  unbetas <- matrix(0, nrow=(ncol(X)+1), ncol=length(lambda))
  #bbetas <- betas/attr(XX, "scale")[ns]
  #bbetas <- betas # if unstandard
  bbetas <- betas/as.vector(stdX$s)
  unbetas[ns+1,] <- bbetas  
  unbetas[1,] <- constant - crossprod(as.vector(stdX$c), bbetas)
  
  
  
  ## Names
  varnames <- if (is.null(colnames(X))) paste("V",1:ncol(X),sep="") else colnames(X)
  varnames <- c("(Intercept)", varnames)
  dimnames(unbetas) <- list(varnames, lambda)
  
  
  ## Output
  output <- structure(list(betas = unbetas,
                        lambda = lambda),
                   class = "rbridge")
  output
}
