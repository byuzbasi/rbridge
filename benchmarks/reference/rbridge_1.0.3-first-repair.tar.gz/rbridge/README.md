<img src="man/figures/banner.svg" alt="rbridge: Restricted Bridge Estimation" width="100%">

`rbridge` fits bridge-penalized linear models with optional linear coefficient
restrictions. The R interface provides coefficient paths, cross-validation,
predictions and coefficient extraction through compiled RcppArmadillo solvers.

The methodology is described in [Yuzbasi, Arashi and Akdeniz (2021),
*Penalized regression via the restricted bridge estimator*](https://doi.org/10.1007/s00500-021-05763-9).
The banner is decorative artwork.

## Install from source

The package is [currently archived on CRAN](https://cran.r-project.org/package=rbridge).
This source tree contains the unreleased 1.0.3 maintenance update. It requires R,
a working C++ toolchain, and the Rcpp, RcppArmadillo and Matrix packages.

Run this command in the package source directory:

```sh
R CMD INSTALL .
```

Alternatively, install the built source archive from R:

```r
install.packages("rbridge_1.0.3.tar.gz", repos = NULL, type = "source")
```

## A small working example

This is a demonstration with synthetic data, not a reproduction of the paper's
reported numerical results. It uses the historical example seed and a short
penalty grid.

```r
library(rbridge)
set.seed(2019)
X <- matrix(rnorm(40 * 4), 40, 4)
y <- as.numeric(1 + X %*% c(1, 0.5, -0.2, 0) + rnorm(40))

# Restrict the fourth standardized predictor coefficient to zero.
R <- matrix(c(0, 0, 0, 1), nrow = 1)
r <- matrix(0, nrow = 1)
fit <- cv.rbridge(
  X, y, q = 2, R = R, r = r,
  lambda = c(5, 2, 1), nfolds = 4, num_threads = 1
)
coef(fit, s = "lambda.min")
predict(fit, newx = X[1:3, , drop = FALSE])
plot(fit)
```

## Functions

| Function | Purpose |
| --- | --- |
| `bridge()` | Unrestricted bridge coefficient path |
| `rbridge()` | Bridge coefficient path with linear restrictions |
| `cv.bridge()` | Cross-validation for an unrestricted model |
| `cv.rbridge()` | Cross-validation for a restricted model |
| `coef()` / `predict()` | Extract coefficients or predict from fitted models |
| `plot()` | Display cross-validation errors and selected penalties |

The supported penalty exponent is positive and at most two. The exponent
controls the bridge penalty; one and two give the L1 and L2 penalty forms.
The solver uses local quadratic approximation and the historical elimination
and convergence thresholds.

## Coefficient scales and selectors

**Restrictions apply to standardized predictor coefficients.** Predictors are
centered and divided by their root-mean-square centered deviations before fitting.
Returned coefficients include a reconstructed intercept and are on the original
predictor scale. Consequently, applying the same restriction matrix directly to
returned slopes generally tests a different restriction. The intercept is not
part of the restriction matrix.

For CV objects, prediction defaults to `lambda.min`; coefficient extraction
defaults to `lambda.1se`. For path objects, omitting `s` returns the entire path.
A numeric `s` selects exact values already present in the fitted lambda grid;
there is no interpolation. A path object's `s = "lambda.min"` selects the
smallest fitted penalty, while `lambda.1se` requires a CV object. Nonzero indices
are reported over the whole fitted path, preserving the historical behavior.

The historical contiguous fold allocation and CV-error aggregation are retained.
Use `num_threads = 1` for a sequential demonstration; multithreading depends on
the build's OpenMP support.

## Guides and citation

* [Reproducibility and validation scope](inst/doc/reproducibility.md)
* [Version notes](NEWS.md)
* [Contributing](CONTRIBUTING.md)
* [Source repository](https://github.com/byuzbasi/rbridge)
* [Report a reproducible issue](https://github.com/byuzbasi/rbridge/issues)

```r
citation("rbridge")
```

Yuzbasi, B., Arashi, M. and Akdeniz, F. (2021). Penalized regression via the
restricted bridge estimator. *Soft Computing*, **25**, 8401-8416.
[doi:10.1007/s00500-021-05763-9](https://doi.org/10.1007/s00500-021-05763-9).

The package is licensed under GPL-3. Utility-function attribution inherited from
the original source is retained.
